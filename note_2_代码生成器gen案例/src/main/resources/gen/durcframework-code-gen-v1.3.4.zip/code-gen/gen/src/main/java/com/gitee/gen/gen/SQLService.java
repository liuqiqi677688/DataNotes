package com.gitee.gen.gen;


public interface SQLService {

	TableSelector getTableSelector(GeneratorConfig generatorConfig);

}
